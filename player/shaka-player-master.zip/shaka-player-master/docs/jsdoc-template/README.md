(Forked from the default JSDoc template, v4.0.0-dev commit be92bc97)
