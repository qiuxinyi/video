## Architecture Diagrams

![Shaka data flow diagram](dataflow.gv.png)

![Shaka ownership diagram](ownership.gv.png)

![Shaka cast diagram](cast.gv.png)

![Shaka offline diagram](offline.gv.png)

![PresentationTimeline diagram](timeline.svg)

![Demo page architecture](newdemo.gv.png)
