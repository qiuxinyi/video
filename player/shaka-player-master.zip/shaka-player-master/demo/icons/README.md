All of the icon files prefixed with "baseline_" are assets from the MDL icons.
All of the icon files prefixed with "custom_" are new assets we made.

All custom icons were made using the font "Fishmonger Cb Plain"
